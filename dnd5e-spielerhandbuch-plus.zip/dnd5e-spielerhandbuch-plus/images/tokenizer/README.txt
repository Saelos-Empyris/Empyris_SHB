Zur Integration vorbereiteter Tokenizer-Tokens wie folgt vorgehen:

1. Den gesamten Ordner "npc-images" in das Verzeichnis "Data\tokenizer\" kopieren.
*auf TheForge-Servern befindet sich das Data-Verzeichnis im Hauptpfad der Asset-Bibliothek, in dem auch die Ordner "modules" und "tokenizer" zu sehen sind.

2. FVTT-Server neu starten.

Anschließend sollten alle Tokens der vorhandenen Kreaturen automatisch eingelesen werden können.